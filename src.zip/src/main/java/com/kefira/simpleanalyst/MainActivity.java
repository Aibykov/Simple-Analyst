package com.kefira.simpleanalyst;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        VideoView videoView = findViewById(R.id.videoViewMain);
        videoView.setVideoPath("android.resource://" + getPackageName() + "/" + R.raw.wallpaper);
        videoView.start();
    }
    public void goPDN_Activity(View v){
        Intent intent = new Intent(this, PdnCalculator.class);
        startActivity(intent);
    }
    public void goFinancialStability_Activity(View v){
        Intent intent = new Intent(this, FinancialStability.class);
        startActivity(intent);
    }
    public void goEveryMonthPay_Activity(View v){
        Intent intent = new Intent(this, EveryMonthPay.class);
        startActivity(intent);
    }
    public void goDepositCalc_Activity(View v){
        Intent intent = new Intent(this, DepositCalculator.class);
        startActivity(intent);
    }

    public void clickInfo(View v){
        showInfoAlert("При расчете финансовой устойчивости используется модель Альтмана, " +
                "по которой вероятность банкротства будет низкая, если индекс больше 2.9, " +
                "высокая при коэффиценте меньше 1.8 и на среднем уровне, если он будет между " +
                "данными значениями.");
    }

    private void showInfoAlert(String text){
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Финансовая устойчивость")
                .setMessage(text)
                .setCancelable(true);
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}