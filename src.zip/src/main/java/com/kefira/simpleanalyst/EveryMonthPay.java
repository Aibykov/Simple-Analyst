package com.kefira.simpleanalyst;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.VideoView;

public class EveryMonthPay extends AppCompatActivity {

    private EditText sum_credit, year_procent, time_credit;
    private Button out1_button, out2_button, clickOn_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_every_month_pay);

        out1_button    = findViewById(R.id.field_for_every_month_pay);
        out2_button    = findViewById(R.id.field_for_pay_sum);
        clickOn_button = findViewById(R.id.button_ok_credit);
        sum_credit     = findViewById(R.id.p_sum_of_credit);
        year_procent   = findViewById(R.id.p_year_procent);
        time_credit    = findViewById(R.id.p_time_credit);

        clickOn_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float  annualInterestRate = Float.parseFloat(year_procent.getText().toString());
                int    loanTermMonths = Integer.parseInt(time_credit.getText().toString());
                float  loanAmount = Float.parseFloat(sum_credit.getText().toString());

                double monthlyInterestRate = annualInterestRate / 100 / 12;
                double monthlyPayment = (loanAmount * monthlyInterestRate) / (1 - Math.pow(1 + monthlyInterestRate, -loanTermMonths));
                double totalPayment = monthlyPayment * loanTermMonths;

                out1_button.setText(String.valueOf(monthlyPayment));

                out2_button.setText(String.valueOf(totalPayment));
            }
        });

    }
    public void goMain_Activity(View v) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}