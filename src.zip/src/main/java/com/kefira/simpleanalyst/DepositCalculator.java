package com.kefira.simpleanalyst;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.VideoView;

public class DepositCalculator extends AppCompatActivity {
    private EditText sum_deposit, year_percent, time_deposit, get_percent;
    private Button out1_button, clickOn_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deposit_calculator);

        year_percent   = findViewById(R.id.p_year_procent_deposit);
        clickOn_button = findViewById(R.id.button_ok_deposit);
        out1_button    = findViewById(R.id.out_sum_deposit);
        time_deposit   = findViewById(R.id.p_time_deposit);
        sum_deposit    = findViewById(R.id.p_sum_deposit);
        get_percent    = findViewById(R.id.p_get_procent);

        clickOn_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ввод суммы вклада
                float depositAmount = Float.parseFloat(sum_deposit.getText().toString());

                // Ввод срока размещения вклада в месяцах
                int depositTermMonths = Integer.parseInt(time_deposit.getText().toString());

                // Выбор варианта выплаты процентов (1 - ежемесячно, 2 - в конце срока)
                int interestPaymentOption = Integer.parseInt(get_percent.getText().toString());

                // Ввод процентной ставки
                float annualInterestRate = Float.parseFloat(year_percent.getText().toString());
                double monthlyInterestRate = annualInterestRate / 100 / 12;

                // Расчет суммы на вкладе к концу срока
                double finalDepositAmount = calculateFinalDepositAmount(depositAmount, depositTermMonths, monthlyInterestRate, interestPaymentOption);

                // Вывод результатов
                finalDepositAmount = (double) Math.round(finalDepositAmount * 100) / 100;
                out1_button.setText(String.valueOf(finalDepositAmount));
            }
        });

    }
    public static double calculateFinalDepositAmount(double principal, int termMonths, double monthlyInterestRate, int interestPaymentOption) {
        if (interestPaymentOption == 1) {
            // Ежемесячная капитализация процентов
            for (int i = 0; i < termMonths; i++) {
                principal += principal * monthlyInterestRate;
            }
        } else if (interestPaymentOption == 2) {
            // Проценты добавляются к вкладу в конце срока
            principal += principal * monthlyInterestRate * termMonths;
        }
        return principal;
    }

    public void goMain_Activity(View v) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}