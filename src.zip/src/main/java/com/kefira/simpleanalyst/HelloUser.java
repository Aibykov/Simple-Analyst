package com.kefira.simpleanalyst;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class HelloUser extends AppCompatActivity {
    //public Button startWorking;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hello_user);
    }
        public void startWorking(View v){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
}