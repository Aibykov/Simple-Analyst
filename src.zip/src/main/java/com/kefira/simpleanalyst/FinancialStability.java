package com.kefira.simpleanalyst;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.VideoView;

public class FinancialStability extends AppCompatActivity {

    private TextView rezultTextView;
    private EditText b1, b2, b3, b4, b5, b_amount;
    private Button rezult_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_financial_stability);

        rezultTextView = findViewById(R.id.rezultTextView);
        rezult_button = findViewById(R.id.button_ok_fs);
        b_amount = findViewById(R.id.Pb_amount);
        b1 = findViewById(R.id.Pb1);
        b2 = findViewById(R.id.Pb2);
        b3 = findViewById(R.id.Pb3);
        b4 = findViewById(R.id.Pb4);
        b5 = findViewById(R.id.Pb5);

        rezult_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float k1 = Float.parseFloat(b1.getText().toString());
                float k2 = Float.parseFloat(b1.getText().toString());
                float k3 = Float.parseFloat(b3.getText().toString());
                float k4 = Float.parseFloat(b4.getText().toString());
                float k5 = Float.parseFloat(b5.getText().toString());
                float k_amount = Float.parseFloat(b_amount.getText().toString());
                k1 = k1 / k_amount;
                k2 = k2 / k_amount;
                k3 = k3 / k_amount;
                k4 = k4 / k_amount;
                k5 = k5 / k_amount;

                double res = 1.2*k1 + 1.4*k2 + 3.3*k3 + 0.6*k4 + 0.999*k5;
                res = (double) Math.round(res * 100) / 100;
                rezult_button.setText(String.valueOf(res));
            }
        });


    }
    public void goMain_Activity(View v) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void clickInfo1(View v){
        showInfoAlertFs("Чистый оборотный капитал является суммой собственных" +
                " средств предприятия, направленных на финансирование операционной деятельности. " +
                "Как правило, это ликвидные средства предприятия, которые легко могут быть " +
                "обращены в денежные средства.\n" +
                "Величина чистого оборотного капитала может принимать нулевое, положительное " +
                "и отрицательное значение.\n");
    }
    public void clickInfo2(View v){
        showInfoAlertFs("Чистая прибыль — это доход бизнеса. " +
                "Сумма, которая остаётся после вычета всех расходов, " +
                "налогов и выплат по кредитам.");
    }
    public void clickInfo3(View v){
        showInfoAlertFs("Операционная прибыль, также называемая прибылью до уплаты " +
                "процентов и налогов (EBIT), — это сумма выручки, которая остается после " +
                "вычета прямых и косвенных операционных расходов компании.");
    }
    public void clickInfo4(View v){
        showInfoAlertFs("Собственный капитал - это разница между стоимостью активов " +
                "компании и суммой ее обязательств. Это все, что останется у компании " +
                "после необходимых выплат и погашения долгов.");
    }
    public void clickInfo5(View v){
        showInfoAlertFs("Чистый объем продаж — Общая стоимость проданных предприятием " +
                "товаров и услуг за вычетом стоимости проданного товара в кредит.");
    }
    public void clickInfo6(View v){
        showInfoAlertFs("Сумма активов бухгалтерского баланса – это показатель, " +
                "отражающий общую балансовую стоимость всех видов активов организации.");
    }



    private void showInfoAlertFs(String text){
        AlertDialog.Builder builder = new AlertDialog.Builder(FinancialStability.this);
        builder.setTitle("Краткие сведения")
                .setMessage(text)
                .setCancelable(true);
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}